---
name: Snap Food Brand System
colors:
  surface: '#fff8f5'
  surface-dim: '#e3d8d1'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fdf1ea'
  surface-container: '#f7ece5'
  surface-container-high: '#f1e6df'
  surface-container-highest: '#ebe0d9'
  on-surface: '#201b17'
  on-surface-variant: '#4e4634'
  inverse-surface: '#352f2b'
  inverse-on-surface: '#faefe8'
  outline: '#7f7662'
  outline-variant: '#d1c5ae'
  surface-tint: '#755b00'
  primary: '#755b00'
  on-primary: '#ffffff'
  primary-container: '#e4b935'
  on-primary-container: '#5f4a00'
  inverse-primary: '#edc13d'
  secondary: '#b32910'
  on-secondary: '#ffffff'
  secondary-container: '#fa5b3d'
  on-secondary-container: '#580800'
  tertiary: '#686000'
  on-tertiary: '#ffffff'
  tertiary-container: '#d1c100'
  on-tertiary-container: '#554e00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffe08e'
  primary-fixed-dim: '#edc13d'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#584400'
  secondary-fixed: '#ffdad3'
  secondary-fixed-dim: '#ffb4a5'
  on-secondary-fixed: '#3e0400'
  on-secondary-fixed-variant: '#8e1400'
  tertiary-fixed: '#f7e624'
  tertiary-fixed-dim: '#dac900'
  on-tertiary-fixed: '#1f1c00'
  on-tertiary-fixed-variant: '#4e4800'
  background: '#fff8f5'
  on-background: '#201b17'
  surface-variant: '#ebe0d9'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 38px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 26px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-xxl: 3rem
---

## Brand & Style

This design system expresses a vibrant, appetizing, and ultra-responsive food delivery experience tailored for on-the-go neighborhood cravings. Combining the energetic optimism of modern food culture with high-utility e-commerce, the system balances tactile charm with crisp transactional efficiency. 

The emotional tone evokes hunger, immediate gratification, trust, and community warmth. Stylistically, the system balances High-Contrast / Bold commerce principles with Tactile Warmth: chunky interactive elements, deep rounded profiles, pill containers, high legibility, and deliberate moments of mascot character integration across onboarding, empty states, and order celebration screens.

## Colors

The palette directly translates appetite and momentum into UI semantics:
- **Primary Golden Yellow (`#E4B935`)**: The core anchor of the brand. Used for primary CTA containers, brand badging, and active navigation nodes.
- **Secondary Food Red (`#D54126`)**: The dynamic culinary driver. Deployed for immediate conversions ("Order Now", "Add to Bag"), price tags, discounts, real-time delivery alerts, and destructive actions.
- **Tertiary Accent Yellow (`#FBE929`)**: High-visibility punch accent. Reserved for micro-highlights, flash sale banners, and active rating star surfaces.
- **Neutral Dark Warm Black (`#1E1915`)**: Deep charcoal espresso tone providing supreme typographic contrast without the stark harshness of pure `#000000`.
- **Surfaces & Borders**:
  - Main Canvas (`#FFFDF7`): Creamy warm base reducing eye fatigue.
  - Card & Modal Elevated Surface (`#FFFFFF`): Crisp white card layer providing contrast above canvas.
  - Soft Neutral Border (`#E9E4D8`): Hairline boundary definition for cards and split rows.
  - Tonal Surface Yellow (`#FFF3C4`): Low-intensity golden tint for info callouts, promo containers, and selected filters.
  - Tonal Surface Red (`#FBE3DC`): Soft peach tint for live tracking chips, cart discounts, and cancellation notices.

## Typography

`Plus Jakarta Sans` delivers a friendly, energetic, yet meticulously structured appearance across all interfaces. The rounded counters and geometric precision echo the bouncy spirit of the brand while preserving maximum clarity in menus, order receipts, price tags, and transit timings.

- Headings use ExtraBold (`800`) and Bold (`700`) weights to produce clean visual separation against packed food photo grids.
- Price tags always leverage `label-lg` or `title-md` set in Bold (`700`) or ExtraBold (`800`) with tight letter spacing for fast numeric scanning.
- Metadata and delivery metrics (distance, eta, ratings) leverage `body-sm` and `label-md` to remain distinct beneath restaurant names.

## Layout & Spacing

The layout is built around mobile-first utility, supporting swift one-thumb interaction and dense visual browsing:
- **Mobile Grid**: 4 columns with `0.75rem` (`12px`) gutters and `1rem` (`16px`) side margins. Bottom safe-area clearance of `4.5rem` reserved for sticky carts and nav bars.
- **Tablet Grid**: 8 columns with `1rem` (`16px`) gutters and `1.5rem` (`24px`) margins. Dual-pane layout separates merchant lists from order previews.
- **Desktop Grid**: 12 columns with `1.5rem` (`24px`) gutters, max content width capped at `1200px` centered with variable dynamic margin.

Spacing rhythm relies on multiples of 4px / 8px:
- `space-xs` (`4px`): Micro badge padding and icon-to-label inline offsets.
- `space-sm` (`8px`): Element grouping gaps within cards, modifier tags, and chips.
- `space-md` (`16px`): Core interior card padding, row gaps between catalog items.
- `space-lg` (`24px`): Section breaks, sheet padding, and header spacing.
- `space-xl` (`32px`): Module separations on home displays.

## Elevation & Depth

Visual hierarchy employs a fusion of warm tonal layering and soft ambient drop shadows tinted with the brand neutral tone:
- **Level 0 (Flat)**: The canvas sits on Warm Surface (`#FFFDF7`). 
- **Level 1 (Card & Section Containers)**: `#FFFFFF` panels framed with a `1px` solid Soft Border (`#E9E4D8`) and an ambient shadow `0 2px 8px -2px rgba(30, 25, 21, 0.04)`.
- **Level 2 (Interactive Floating Elements & Food Cards)**: Floating filter bars, dish hover/press cards, and merchant cards elevate with `0 6px 16px -4px rgba(30, 25, 21, 0.08)`.
- **Level 3 (Sticky Checkout Banners & Modals)**: Bottom checkout drawers, sticky cart pills, and bottom navigation elevate with `0 12px 32px -6px rgba(30, 25, 21, 0.12)`.
- **Mascot Highlights**: The courier mascot and order status celebrations project dynamic layered pop-outs, breaking outside boundaries with a punchy directional drop shadow `0 8px 0px 0px rgba(30, 25, 21, 0.08)` to sustain physical playfulness.

## Shapes

The interface embraces a chunky, friendly geometric shape grammar:
- Base elements (cards, text input fields, list tiles) feature `rounded-lg` (`16px` / `1rem`) corner radii to maintain soft, approachable boundaries.
- Badges, status pills, category icons, and high-frequency CTAs utilize full pill radiuses (`9999px`) to invite thumb taps and simulate handheld tokens.
- Food preview images adopt matching `12px` to `16px` radii, preventing harsh cut-offs against soft card outlines.

## Components

### Buttons
- **Primary CTA ("Order Now", "Checkout")**: Food Red (`#D54126`) background, text in `#FFFFFF`, ExtraBold 700. Min touch height: `52px` (mobile), border radius `9999px` (pill). Active state triggers subtle scale press (`0.98`).
- **Secondary CTA ("Add to Cart", "Reorder")**: Primary Golden Yellow (`#E4B935`) background with Warm Black (`#1E1915`) text.
- **Tertiary / Utility Button**: Crisp White (`#FFFFFF`) with `1.5px` border in `#E9E4D8`, Warm Black text.
- **Floating Cart Button**: Sticky bottom-docked pill, dual-toned: left side details item count and total sum, right side Food Red action arrow.

### Chips & Filter Pills
- Inactive: Background `#FFFFFF`, border `1px` solid `#E9E4D8`, text Warm Black.
- Active: Background Light Yellow Surface (`#FFF3C4`), border `1.5px` solid `#E4B935`, font-weight `700`.

### Cards
- **Merchant Card**: `#FFFFFF` background, `16px` border-radius, `1px` `#E9E4D8` border. Header features a `16:9` food photography container overlaid with a pill badge for ETA and delivery fee. Title in `title-md`, secondary stats (rating star in `#FBE929`, count) in `body-sm`.
- **Dish Row Card**: Horizontal mobile format. Left side details item title, brief ingredient summary, and bold price tag; right side houses square `84px` dish thumbnail with quick-action floating `+` pill overlapping the bottom edge.

### Input Fields
- Heights set to `48px` to ensure mobile tap comfort.
- Background `#FFFFFF`, border `1.5px` solid `#E9E4D8`, radius `12px`.
- Focus state switches border to Primary Golden Yellow (`#E4B935`) accompanied by a subtle `3px` focus ring tinted `rgba(228, 185, 53, 0.20)`.

### Checkboxes, Steppers & Radio Buttons
- Quantity stepper: Horizontal pill container with Light Yellow Surface (`#FFF3C4`), featuring chunky `+` and `−` symbols in Warm Black, centered numeric count in `label-lg`.
- Radio Buttons / Checkboxes: Food Red fill on select with white indicator mark; unselected displays `1.5px` Warm Black outline.

### Mascot States (Selective Moments)
- **Onboarding**: Scooter mascot introducing swift neighborhood delivery.
- **Empty States (Search, Cart)**: Mascot peering into empty takeout box with cheerful copy and clear actionable search/browse CTA.
- **Live Order Progress**: Animated scooter icon moving across custom map route tracker with warm yellow pathing and red checkpoint markers.